---
title: "Develop"
weight: [Replace with weight]
geekdocCollapseSection: true
geekdocHidden: false
---

The presented Microsoft Azure Well-Architected Framework recommendations in this guidance include the Develop Stage and associated resources and their settings.

{{< azure-waf-recommendationlist name="azure-waf-recommendationlist" >}}
