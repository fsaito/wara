---
title: "{{ replace .Name "-" " " | title }}"
geekdocCollapseSection: true
geekdocHidden: false
---

## Relevant Azure Resource Recommendations

| Recommendation                                                                                   | Provider Namespace |  Resource Type  |
| :----------------------------------------------------------------------------------------------- | :----------------: | :-------------: |
| [Replace with existing recommendation description value](Replace with existing recommendation URL) |       Batch        |  batchAccounts  |
| [Replace with existing recommendation description value](Replace with existing recommendation URL) |      Storage       | storageAccounts |

## General Guidance (not resource specific)

{{< azure-resources-recommendationlist name="azure-resources-recommendationlist" >}}
