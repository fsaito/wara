---
title: "{{ replace .Name "-" " " | title }}"
weight: [Replace with weight]
geekdocCollapseSection: true
geekdocHidden: false
---

The presented Microsoft Azure Well-Architected Framework recommendations in this guidance include [Replace with the stage name] Stage “[Replace with the stage number] and associated resources and their settings.

[Replace with an overview/description of the stage]

{{< azure-waf-recommendationlist name="azure-waf-recommendationlist" >}}
