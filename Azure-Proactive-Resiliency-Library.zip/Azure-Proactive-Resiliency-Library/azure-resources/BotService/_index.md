---
title: BotService
geekdocCollapseSection: true
geekdocHidden: true
---
