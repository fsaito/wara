---
title: CognitiveServices
geekdocCollapseSection: true
geekdocHidden: true
---
