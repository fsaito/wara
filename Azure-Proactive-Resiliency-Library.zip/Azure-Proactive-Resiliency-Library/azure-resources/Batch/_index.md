---
title: Batch
geekdocCollapseSection: true
geekdocHidden: false
---
