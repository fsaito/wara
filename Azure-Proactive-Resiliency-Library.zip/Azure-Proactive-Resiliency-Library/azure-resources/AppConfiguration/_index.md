---
title: AppConfiguration
geekdocCollapseSection: true
geekdocHidden: true
---
