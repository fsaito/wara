---
title: PowerBIDedicated
geekdocCollapseSection: true
geekdocHidden: true
---
