---
title: StreamAnalytics
geekdocCollapseSection: true
geekdocHidden: true
---
