---
title: Bing
geekdocCollapseSection: true
geekdocHidden: true
---
