---
title: Cache
geekdocCollapseSection: true
geekdocHidden: false
---
