---
title: databaseAccounts
geekdocCollapseSection: true
geekdocHidden: false
---

{{< azure-resources-recommendationlist name="azure-resources-recommendationlist" >}}
